<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <style>
        #fundo
        {
            background-color:light-purple;

        }
    </style>
</head>
<body>
    
    <div id="fundo"></div>
    <form action="cadastro.php" method="post">
        <div>
        <label for="name">Usuário:</label>
        <input type="text" id="name" name="name" required>
        <br><br>
        
        <label for="password">Senha:</label>
        <input type="password" id="password" name="password" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>
        <br><br><br>

        <button id="button" type="submit" name="entrar">Cadastrar</button><br><br>
    </form>
</body>
</html>

<?php

    extract($_POST);

    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $usuariocriptografado = md5($_POST["name"]);
        $senhacriptografada = md5($_POST["password"]);

        $sql = "INSERT INTO users (usuario,passwrd,email) VALUES ('".$usuariocriptografado."', '".$senhacriptografada."','".$_POST["email"]."');";

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute())
        {
            echo "Cadastro realizado com sucesso!";
        }
        else
        {
            echo "Erro ao cadastrar, tente novamente!";
        }
    }
?>