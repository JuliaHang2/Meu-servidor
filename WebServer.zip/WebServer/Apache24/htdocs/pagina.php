
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página</title>
</head>
<body>
    
    <form action="pagina.php" method="post">
        <div>
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required>
        <br><br>
        
        <label for="password">Senha:</label>
        <input type="password" id="password" name="password" required>
        <br><br>
 
        
        <button id="button" type="submit" name="entrar">Entrar</button>
    </form>
</body>
</html>

<?php

    extract($_POST);
    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        

        $sql = "SELECT usuario, passwrd FROM users WHERE usuario = '".$_POST["name"]."' AND passwrd = '".$_POST["password"]."';";

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute())
        {
            while($linha = $query->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }
            if($indice == 1)
            {
                print_r($linhas);
            }
        else
        {
            echo "Usuário e senha não existem, verifique!";
        }
        }
    }
?>